
document.addEventListener('DOMContentLoaded', function() {

    let input = document.getElementById('input');

    window.insertNumber = function(number) {
        input.value += number;
    }

    window.insertOperator = function(operator) {
        let lastChar = input.value.slice(-1);
        if (['+', '-', '*', '/', '.'].includes(lastChar)) {
            return;
        }
        input.value += operator;
    }

    window.clearAll = function() {
        input.value = '';
    }

    window.clearLast = function() {
        input.value = input.value.slice(0, -1);
    }

    window.calculate = function() {
        try {
            let expression = input.value;
            if (!expression) return;

            if (/^[0-9+\-*/.() ]+$/.test(expression)) {
                let result = eval(expression);

                if (result === Infinity || result === -Infinity) {
                    input.value = 'Error: Division by zero';
                    return;
                }

                if (Number.isFinite(result)) {
                    input.value = Number(result.toFixed(8));
                } else {
                    input.value = 'Error';
                }
            } else {
                input.value = 'Error';
            }
        } catch (error) {
            input.value = 'Error';
        }
    }

    // Add keyboard event listener
    document.addEventListener('keydown', function(event) {
        const key = event.key;

        if (/^[0-9]$/.test(key)) {
            window.insertNumber(key);
        }
        else if (['+', '-', '*', '/', '.'].includes(key)) {
            window.insertOperator(key);
        }
        else if (key === 'Enter') {
            window.calculate();
        }
        else if (key === 'Backspace') {
            window.clearLast();
        }
        else if (key === 'Escape') {
            window.clearAll();
        }
    });
});
